CSEC用原稿ソース（2026-10-27）

main.tex / references.bib / IPSJクラス・スタイル / 使用図 / build.ps1 を同梱。
zipを展開したフォルダで、pLaTeX・pBibTeX・dvipdfmxを利用できる環境から
PowerShellで次を実行してください。

    powershell -File ./build.ps1

またはTeX Live等のpLaTeX + pBibTeX + dvipdfmxでmain.texをコンパイルします。
クラス・スタイルの著作権表示は各原本を参照してください。
実験プログラムや全データセットは、この原稿ソースzipには含めていません。
